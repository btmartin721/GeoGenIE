from pathlib import Path
import pandas as pd
import numpy as np


def calculate_statistics(input_directory, output_file):
    """Calculates statistics for each .csv file in the directory.

    Args:
        input_directory (str): Path to the directory containing .csv files.
        output_file (str): Path to save the output summary .csv file.

    """
    # List to store the summary statistics
    summary_stats = []

    # Iterate over files in the directory
    for file_name in Path(input_directory).glob("*.csv"):
        file_path = Path(input_directory, file_name)
        try:
            # Read the CSV file
            df = pd.read_csv(file_path)

            # Calculate stats for numeric columns
            for column in df.select_dtypes(include=[np.number]).columns:
                mean_val = df[column].mean()
                median_val = df[column].median()
                std_val = df[column].std()

                # Append results to the summary list
                summary_stats.append(
                    {
                        "File": file_name.stem.replace(
                            "_N1149_L436_execution_times", ""
                        ),
                        "Column": column,
                        "Mean": mean_val,
                        "Median": median_val,
                        "Standard Deviation": std_val,
                    }
                )
        except Exception as e:
            print(f"Error processing file {file_name}: {e}")

    # Create a DataFrame from the summary statistics
    summary_df = pd.DataFrame(summary_stats)

    # Save the summary table to a .csv file
    summary_df.to_csv(output_file, index=False)
    print(f"Summary statistics saved to {output_file}")


# Define the input directory and output file
input_directory = "/Users/btm002/Documents/research/GeoGenIE/analyses/wtd_gtseq_N1149_L436_sweep_28Nov2024/benchmarking"
output_file = "/Users/btm002/Documents/research/GeoGenIE/analyses/summaries/summary_28Nov2024/per_boot_summary_statistics.csv"

# Run the function
calculate_statistics(input_directory, output_file)
