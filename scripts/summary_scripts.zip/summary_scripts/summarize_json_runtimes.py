import json
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import pandas as pd
import numpy as np

gg_base_json = Path(
    "analyses/summaries/summary_28Nov2024/benchmarking/geogenie_total_runtime_base.json"
)

gg_opt_json = Path(
    "analyses/summaries/summary_28Nov2024/benchmarking/geogenie_total_runtime_opt.json"
)

locator_json = Path(
    "analyses/summaries/summary_28Nov2024/benchmarking/locator_final_results.json"
)

models = ["GeoGenIE (Base Model)", "GeoGenIE (Best Model)", "Locator"]

json_data = {}
for json_file, model in zip([gg_base_json, gg_opt_json, locator_json], models):
    with open(json_file, "r") as f:
        data = json.load(f)
        results = data["results"][0]
        runtimes = results["times"]
        stmp = pd.Series(runtimes)
        json_data[model] = stmp

df = pd.DataFrame(json_data)

# Convert seconds to minutes
df = df / 60

df_melt = df.melt(var_name="Model", value_name="Time (min)")
df_melt = df_melt[df_melt["Time (min)"] >= 10]

mpl.rcParams["font.size"] = 22
mpl.rcParams["axes.labelsize"] = 22
mpl.rcParams["xtick.labelsize"] = 22
mpl.rcParams["ytick.labelsize"] = 22
mpl.rcParams["legend.fontsize"] = 22
mpl.rcParams["figure.titlesize"] = 22

# Plotting
fig, ax = plt.subplots(figsize=(6, 12))

sns.set_style(style="white")
sns.despine()

ax = sns.boxplot(
    x="Model",
    y="Time (min)",
    hue="Model",
    hue_order=["Locator", "GeoGenIE (Base Model)", "GeoGenIE (Best Model)"],
    order=["Locator", "GeoGenIE (Base Model)", "GeoGenIE (Best Model)"],
    data=df_melt,
    ax=ax,
    legend=True,
)

# Adding labels and customization
ax.set_xticks(ax.get_xticks())
ax.set_xticklabels(["" for i in ax.get_xticks()])
ax.set_yticks(np.arange(0, 41, 5))
ax.set_yticklabels([str(i) for i in np.arange(0, 41, 5)])
ax.set_xlabel("")
ax.set_ylabel("Time (minutes)")
ax.set_ylim(bottom=0, top=40)
ax.legend(loc="best", title="Model", title_fontsize=22, fancybox=True, shadow=True)

fig.savefig(
    Path(gg_base_json.parent) / "locator_vs_geogenie_runtime_boxplot.pdf",
    bbox_inches="tight",
)
plt.close()

print(f"Locator Mean: {df_melt[df_melt["Model"] == "Locator"]["Time (min)"].mean()}")
print(f"Locator StdDev: {df_melt[df_melt['Model'] == 'Locator']['Time (min)'].std()}")
print(
    f"GeoGenIE Base Mean: {df_melt[df_melt["Model"] == "GeoGenIE (Base Model)"]["Time (min)"].mean()}"
)
print(
    "GeoGenIE Base StdDev:",
    df_melt[df_melt["Model"] == "GeoGenIE (Base Model)"]["Time (min)"].std(),
)
print(
    f"GeoGenIE Best Mean: {df_melt[df_melt['Model'] == 'GeoGenIE (Best Model)']['Time (min)'].mean()}"
)
print(
    "GeoGenIE Best StdDev:",
    df_melt[df_melt["Model"] == "GeoGenIE (Best Model)"]["Time (min)"].std(),
)
