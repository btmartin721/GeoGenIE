from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def main():
    # Get the path to the directory containing the execution times
    locator_dir = Path("analyses", "locator_rerun_sameSamples_FINAL_FINAL3_27Nov2024")
    gg_dir = Path("analyses/wtd_gg_27Nov2024_best/benchmarking")

    locator_file = locator_dir / "locator_rerun_sameSamples_execution_times.csv"
    gg_files = list(gg_dir.glob("*_execution_times.csv"))[0]

    dfgg = pd.read_csv(gg_files)
    dfgg = dfgg.drop(columns=["Function Name"])
    dfgg["Model"] = "GeoGenIE (Best Model)"

    dfloc = pd.read_csv(locator_file)
    dfloc = dfloc.drop(columns=["Function Name"])
    dfloc["Model"] = "Locator"

    df = pd.concat([dfgg, dfloc])

    # Convert the execution_time column to numeric
    df["Execution Time"] = pd.to_numeric(df["Execution Time"])

    # Plot
    sns.set_style("white")

    fig, ax = plt.subplots(figsize=(16, 9))

    sns.despine(fig, ax)

    ax = sns.boxplot(data=df, x="Model", y="Execution Time", hue="Model", ax=ax)

    ax.set_xlabel("Model", fontsize=24)
    ax.set_ylabel("Execution Time (seconds)", fontsize=24)
    ax.set_title("Locator vs. GeoGenIE Execution Time Benchmarks", fontsize=28)

    ax.legend(
        title="Configuration",
        title_fontsize=24,
        fontsize=20,
        loc="center",
        bbox_to_anchor=(0.5, 1.3),
        ncol=2,
        fancybox=True,
        shadow=True,
    )

    ax.set_xticks(ax.get_xticks())
    ax.set_xticklabels(ax.get_xticklabels(), fontsize=24)

    ax.set_yticks(ax.get_yticks())
    ax.set_yticklabels(ax.get_yticklabels(), fontsize=24)

    ax.set_ylim(bottom=-10)

    fig.savefig(
        "analyses/summaries/execution_times.pdf", bbox_inches="tight", facecolor="white"
    )

    plt.close()

    df_groups = df.groupby(["Model", "Configuration"])["Execution Time"].describe()

    df_groups.to_csv("analyses/summaries/execution_times_summary.csv")


if __name__ == "__main__":
    main()
